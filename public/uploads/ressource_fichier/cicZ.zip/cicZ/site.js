﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {

    $("form").bind("keypress", function (e) {
        if (e.keyCode == 13) {
            return false;
        }
    });

    let loader = $("#loader");
    //loader.addClass("DisplayWrapper");
    //loader.removeClass("DisplayWrapper");

    ///////////////////////////////////////////////////////////////////////////////////// ok
    let cliCod = $("#cliCod");
    let cliCodRemouve = $(".cliCod .glyphicon-remove");
    let cliCodValide = $(".cliCod .glyphicon-ok");
    let inputCliCodRemouve = $('#cliCod~.glyphicon-remove').first();
    let clientAVerifier;

    cliCod.focus();
    cliCod.autocomplete({
        minLength: 3,
        autoFocus: true,
        classes: {
            "ui-autocomplete": "form-label styleList listCliCod",
        },
        search: function (event, ui) {
            $('#messageErrorClicod').hide();

            if (cliCod.val().length > 0) {
                cliCodRemouve.addClass("validGlyphiconRemouve");
            }

            clientAVerifier = true;

            cliCodRemouve.addClass("validGlyphiconRemouve");
        },
        source: function (request, response) {
            $.ajax({
                data: request,
                method: 'POST',
                url: "/cic/getClients",
                success: function (dataResponse) {
                    cliCodValide.removeClass("validGlyphiconOk");
                    clientAVerifier = false;
                    response(dataResponse);
                },
                error: function (errorResponse) {
                    alert(errorResponse + "error ajax autocomplete cliCod");
                }
            });
        },
        response: function (_event, ui) {

            if (!ui.content.length) {

                ui.content.unshift({ label: "oups, aucun résultat.." });
                cliCod.prop("maxLength", cliCod.val().length);  //  -->    on bloque la saisie
            }
            else {
                cliCod.prop("maxLength", 50); //--> on repasse a 50 caractere
            }
        },
        change: function (_event, ui) {
            var verifCilcod = clientAVerifier && $('#cliCod').val().length > 3;
            if (verifCilcod) { clientExist(); }
        },
        close: function (event, ui) { clientExist(); }

    });
    inputCliCodRemouve.click(removeClicod);

    function clientExist() {

        clientAVerifier = false;
        
        if (cliCod.val() != "") {
            $.ajax({
                type: "post",
                url: "/cic/clientExist?cliCod=" + cliCod.val(),
                success: function (data) {
                    if (data) {
                        // true result
                        loader.addClass("DisplayWrapper");
                        searchEtab();
                    } else {
                        // false no result
                        removeClicod();
                        $('#messageErrorClicod').show();
                        HideElementDelivery();
                        HideElementRef();
                        cliCod.focus();
                    }
                },
                error: function (errorResponse) {
                    alert(errorResponse + "error ajax verif client");
                }
            })
        }
    };  
    function removeClicod() {    
        cliCod.focus();
        cliCodValide.removeClass("validGlyphiconOk");
        cliCodRemouve.removeClass("validGlyphiconRemouve");
        cliCod.val('');
        initializEtbNum();
        HideElementRef();
        HideElementDelivery();
        SearchCic.css("visibility", "hidden");

    };
    ///////////////////////////////////////////////////////////////////////////////////// ok
    let etbNum = $("#etbNum");
    let etbNumRemouve = $(".etbNum .glyphicon-remove");
    let etbNumValide = $(".etbNum .glyphicon-ok");
    let inputEtbNumRemouve = $('#etbNum~.glyphicon-remove').first();
    let firstAnswer;

    inputEtbNumRemouve.click(removeEtbNum);
    etbNum.change(inputEtbNum);

    function removeEtbNum() {
        initializEtbNum();
        searchEtab();
        HideElementRef();
        HideElementDelivery();
        SearchCic.css("visibility", "hidden");
    };
    function searchEtab() {
        $.ajax({
            type: "Post",
            url: "/cic/getEtb?cliCod=" + cliCod.val(),
            async: true,
            cache: true,
            success: function (data) {               
                cliCodValide.addClass("validGlyphiconOk");
                initializEtbNum();
                if (data.length > 0) {
                    $.each(data, function (key, value) {
                        etbNum.append("<option class='etablissement' value=" + value + ">" + value + "</option>");
                    });
                }
                loader.removeClass("DisplayWrapper");
                etbNum.focus();
            },
            error: function (ret) {
                alert("error ajax search etablissement");
            }
        })
    };
    function initializEtbNum() {
        etbNumRemouve.removeClass("validGlyphiconRemouve");
        etbNumValide.removeClass("validGlyphiconOk");
        etbNum.empty();
        etbNum.append('<option class="etablissement" value=" ">Sélectionnez</option>');
    };
    function inputEtbNum() {
        HideElementDelivery();
        HideElementRef();
        etbNumValide.addClass("validGlyphiconOk");
        etbNumRemouve.addClass("validGlyphiconRemouve");

        if (etbNum.val() === " ") {
            etbNumValide.removeClass("validGlyphiconOk");
            etbNumRemouve.removeClass("validGlyphiconRemouve");
            HideElementDelivery();
            HideElementRef();
        } else {
            firstAnswer = false;
            searchCustomerRef();
            searchProductRef();
            etbNum.blur();
            loader.addClass("DisplayWrapper");
        };     
    };
    /////////////////////////////////////////////////////////////////////////////////////
    let customerProduct = $("#customerProduct");

    let customerRef = $("#customerRef");
    let customerRefRemouve = $(".customerRef .glyphicon-remove");
    let customerRefValide = $(".customerRef .glyphicon-ok");
    let inputCustomerRefRemouve = $('#customerRef~.glyphicon-remove').first();
    let labelCustomerRef = $('label[for=customerRef]');

    let productRef = $("#productRef");
    let productRefRemouve = $(".productRef .glyphicon-remove");
    let productRefValide = $(".productRef .glyphicon-ok");
    let inputProductRefRemouve = $('#productRef~.glyphicon-remove').first();
    let labelProductRef = $('label[for=productRef]');

    let selectProduct = $('input[name="selectProduct"]');

    selectProduct.click(DisplayElementRef);

    function DisplayElementRef() {
        $('#messageErrorDelivery').hide();
        $('#messageErrorParcelNumber').hide();
        if ($(this).val() == "1") {

            DisplayElementCustomerRef();

        } else if ($(this).val() == "2") {
            DisplayElementProductRef()
        }
    };
    function HideElementRef() {

        customerProduct.removeClass("DisplayElement");
        selectProduct.prop('checked', false);

        customerRef.removeClass("DisplayElement");
        customerRef.val('');
        customerRefRemouve.removeClass("validGlyphiconRemouve");
        customerRefValide.removeClass("validGlyphiconOk");
        
        productRef.removeClass("DisplayElement");
        productRef.val('');
        productRefRemouve.removeClass("validGlyphiconRemouve");
        productRefValide.removeClass("validGlyphiconOk");
        
    };

    inputCustomerRefRemouve.click(removeCustomerRef);
    customerRef.change(inputCustomerRef);
    labelCustomerRef.click(DisplayElementCustomerRef);

    function removeCustomerRef() {
        customerRefValide.removeClass("validGlyphiconOk");
        customerRefRemouve.removeClass("validGlyphiconRemouve");
        customerRef.empty();
        searchCustomerRef();
        SearchCic.css("visibility", "hidden");
    };
    function searchCustomerRef() {
        $.ajax({
            type: "Post",
            url: "/cic/getProduitClients",
            async: true,
            cache: true,
            data: { cliCod: cliCod.val().trim(), etbNum: etbNum.val().trim(), deliverySlipNumber: deliverySlipNumber.val().trim(), parcelNumber: parcelNumber.val().trim() },
            success: function (data) {
                if (customerRef.val() != " " && customerRef.val() != null) {
                    customerRef.empty();
                    customerRef.append('<option class="customerRef" value="' + customerRef.val() + '">' + customerRef.val() + '</option>');
                } else {
                    customerRef.empty();
                    customerRef.append('<option class="customerRef" value=" ">Sélectionnez</option>');
                }
                if (data.length > 0) {
                    $.each(data, function (key, value) {
                        customerRef.append('<option class="customerRef" value="' + value + '">' + value + '</option>');
                    });
                }
                if (firstAnswer === false) {
                    firstAnswer = true
                }
                else {
                    loader.removeClass("DisplayWrapper");
                    customerProduct.addClass("DisplayElement");
                    delivery.addClass("DisplayElement");
                }
            },
            error: function () { alert("error ajax search ref client"); },
        })
    };
    function inputCustomerRef() {
        $('#messageErrorDelivery').hide();
        $('#messageErrorParcelNumber').hide();
        customerRefValide.addClass("validGlyphiconOk");
        customerRefRemouve.addClass("validGlyphiconRemouve");
    };
    function DisplayElementCustomerRef() {
        if ($(this)[0].htmlFor == "customerRef") { console.log($(this)) } 
        productRef.removeClass("DisplayElement");
        customerRef.addClass("DisplayElement");
        customerRef.focus();
        //a verifier
        productRef.selectedIndex = 0; // on enleve si valeur à l'autre element
        productRefValide.removeClass("validGlyphiconOk");
        productRefRemouve.removeClass("validGlyphiconRemouve");
    };

    inputProductRefRemouve.click(removeProductRef);
    productRef.change(inputProductRef);
    labelProductRef.click(DisplayElementProductRef);

    function removeProductRef() {
        productRefValide.removeClass("validGlyphiconOk");
        productRefRemouve.removeClass("validGlyphiconRemouve");
        productRef.empty();
        searchProductRef();
        SearchCic.css("visibility", "hidden");
    };
    function searchProductRef() {
        $.ajax({
            type: "Post",
            url: "/cic/getCodeSilver",
            data: { cliCod: cliCod.val().trim(), etbNum: etbNum.val().trim(), deliverySlipNumber: deliverySlipNumber.val().trim(), parcelNumber: parcelNumber.val().trim() },
            success: function (data) {

                if (productRef.val() != " " && productRef.val() != null) {
                    productRef.empty();
                    productRef.append('<option class="productRef" value="' + productRef.val() + '">' + productRef.val() + '</option>');
                } else {
                    productRef.empty();
                    productRef.append('<option class="productRef" value=" ">Sélectionnez</option>');
                }

                if (data.length > 0) {
                    $.each(data, function (key, value) {
                        productRef.append('<option class="productRef" value="' + value + '">' + value + '</option>');
                    });

                }
                if (firstAnswer === false) {
                    firstAnswer = true
                }
                else {
                    loader.removeClass("DisplayWrapper");
                    customerProduct.addClass("DisplayElement");
                    delivery.addClass("DisplayElement");
                }
            },
            error: function () { alert("error ajax search ref produit"); },
        })
    };
    function inputProductRef() {
        $('#messageErrorDelivery').hide();
        $('#messageErrorParcelNumber').hide();
        productRefValide.addClass("validGlyphiconOk");
        productRefRemouve.addClass("validGlyphiconRemouve");
    };
    function DisplayElementProductRef() {
        if ($(this)[0].htmlFor == "productRef") { console.log($(this)) }    
        customerRef.removeClass("DisplayElement");
        productRef.addClass("DisplayElement");
        productRef.focus();
        //a verifier
        customerRef.selectedIndex = 0;
        customerRefValide.removeClass("validGlyphiconOk");
        customerRefRemouve.removeClass("validGlyphiconRemouve");
    };
    
    /////////////////////////////////////////////////////////////////////////////////////
    let delivery = $("#delivery");

    let deliverySlipNumber = $("#deliverySlipNumber");
    let deliverySlipNumberRemouve = $(".deliverySlipNumber .glyphicon-remove");
    let deliverySlipNumberValide = $(".deliverySlipNumber .glyphicon-ok");
    let inputDeliverySlipNumberRemouve = $('#deliverySlipNumber~.glyphicon-remove').first();
    let labelDeliverySlipNumber = $('label[for=deliverySlipNumber]');
    let deliverySlipNumberAVerifier;

    let parcelNumber = $("#parcelNumber");
    let parcelNumberRemouve = $(".parcelNumber .glyphicon-remove");
    let parcelNumberValide = $(".parcelNumber .glyphicon-ok");
    let inputParcelNumberRemouve = $('#parcelNumber~.glyphicon-remove').first();
    let labelParcelNumber = $('label[for=parcelNumber]');
    let parcelNumberAVerifier;

    let selectDelivery = $('input[name="selectDelivery"]');

    selectDelivery.click(DisplayElementDelivery);

    function DisplayElementDelivery() {

        if ($(this).val() == "1") {
            parcelNumber.removeClass("DisplayElement");
            parcelNumberValide.removeClass("validGlyphiconOk");
            parcelNumberRemouve.removeClass("validGlyphiconRemouve");
            parcelNumber.val("");

            deliverySlipNumber.addClass("DisplayElement");
            deliverySlipNumber.focus();

            $('#messageErrorParcelNumber').hide();

        } else if ($(this).val() == "2") {
            deliverySlipNumber.removeClass("DisplayElement");
            deliverySlipNumberValide.removeClass("validGlyphiconOk");
            deliverySlipNumberRemouve.removeClass("validGlyphiconRemouve");
            deliverySlipNumber.val("");

            parcelNumber.addClass("DisplayElement");
            parcelNumber.focus();

            $('#messageErrorDelivery').hide();
        }
    };
    function HideElementDelivery() {

        delivery.removeClass("DisplayElement");
        selectDelivery.prop('checked', false);

        deliverySlipNumber.removeClass("DisplayElement");
        deliverySlipNumber.val('');
        deliverySlipNumberRemouve.removeClass("validGlyphiconRemouve");
        deliverySlipNumberValide.removeClass("validGlyphiconOk");
        $('#messageErrorDelivery').hide();

        parcelNumber.removeClass("DisplayElement");
        parcelNumber.val('');
        parcelNumberRemouve.removeClass("validGlyphiconRemouve");
        parcelNumberValide.removeClass("validGlyphiconOk");
        $('#messageErrorParcelNumber').hide();

    };

    inputDeliverySlipNumberRemouve.click(removeDelivery);
    deliverySlipNumber.autocomplete({
        minLength: 3,
        autoFocus: true,
        classes: {
            "ui-autocomplete": "form-label styleList listDelivery",
        },
        search: function (event, ui) {

            deliverySlipNumberAVerifier = true;

            if (customerRef.val() === null) {
                customerRef.val(" ");
            }
            if (productRef.val() === null) {
                productRef.val(" ");
            }
            $('#messageErrorDelivery').hide();
            $('#messageErrorParcelNumber').hide();

            deliverySlipNumberRemouve.addClass("validGlyphiconRemouve");
        },
        source: function (request, response) {
            $.ajax({
                method: 'POST',
                url: "getBls",
                data: { term: request.term, cliCod: cliCod.val(), etbNum: etbNum.val(), customerRef: customerRef.val().trim(), productRef: productRef.val().trim() },
                success: function (data) {
                    deliverySlipNumberAVerifier = false;
                    response(data);
                },
                error: function () { alert("error ajax autocomplete Bon livraison"); },
            });
        },
        response: function (_event, ui) {
            if (!ui.content.length) {
                ui.content.unshift({ label: "oups, aucun résultat.." });
                deliverySlipNumber.prop("maxLength", deliverySlipNumber.val().length);//--> on bloque la saisie
            }
            else {
                deliverySlipNumber.prop("maxLength", 50);//--> on repasse a 50 caractere
            }
        },
        change: function (_event, ui) {
            var verifBl = deliverySlipNumberAVerifier && deliverySlipNumber.val().length > 3;
            if (verifBl) { validDeliverySlipNumber(); }
        },
        //select: function (_event, ui) { console.log('select') },
        close: function (event, ui) { validDeliverySlipNumber(); }

    });

    function removeDelivery() {
        deliverySlipNumberValide.removeClass("validGlyphiconOk");
        deliverySlipNumberRemouve.removeClass("validGlyphiconRemouve");
        deliverySlipNumber.val('');
        SearchCic.css("visibility", "hidden");
    };
    function validDeliverySlipNumber() {

        deliverySlipNumberAVerifier = false;

        if (customerRef.val() === null) {
            customerRef.val(" ");
        }
        if (productRef.val() === null) {
            productRef.val(" ");
        }

        if (deliverySlipNumber.val()) {
            $.ajax({
                type: "Post",
                url: "blExist",
                data: { cliCod: cliCod.val().trim(), etbNum: etbNum.val().trim(), customerRef: customerRef.val().trim(), productRef: productRef.val().trim(), deliverySlipNumber: deliverySlipNumber.val().trim()  },
                success: function (data) {

                    if (data) {
                        searchCustomerRef();
                        searchProductRef();
                        deliverySlipNumberValide.addClass("validGlyphiconOk");
                        SearchCic.css("visibility", "visible");


                    } else {
                        $('#messageErrorDelivery').show();
                        removeDelivery()
                        deliverySlipNumberValide.removeClass("validGlyphiconOk");
                    }
                },
                error: function () { alert("error ajax verif Bon livraison"); },
            })
        }

    };
    function DisplayElementDeliverySlipNumber() { };

    inputParcelNumberRemouve.click(removeParcelNumb);
    parcelNumber.autocomplete({
        minLength: 4,
        autoFocus: true,
        classes: {
            "ui-autocomplete": "form-label styleList listParcel",
        },
        search: function (event, ui) {
            parcelNumberAVerifier = true;

            if (customerRef.val() === null) {
                customerRef.val(" ");
            }
            if (productRef.val() === null) {
                productRef.val(" ");
            }
            $('#messageErrorDelivery').hide();
            $('#messageErrorParcelNumber').hide();

            parcelNumberRemouve.addClass("validGlyphiconRemouve");
        },
        source: function (request, response) {
            $.ajax({
                method: 'POST',
                url: "getColis",
                data: { term: request.term, cliCod: cliCod.val().trim(), etbNum: etbNum.val().trim(), customerRef: customerRef.val().trim(), productRef: productRef.val().trim() },
                success: function (data) {
                    parcelNumberAVerifier = false;
                    response(data);
                },
                error: function () { alert("error ajax autocomplete n° de colis"); },
            });
        },
        response: function (_event, ui) {
            if (!ui.content.length) {
                ui.content.unshift({ label: "oups, aucun résultat.." });
                parcelNumber.prop("maxLength", parcelNumber.val().length);//--> on bloque la saisie
            }
            else {
                parcelNumber.prop("maxLength", 50);//--> on repasse a 50 caractere
            }
        },
        change: function (_event, ui) {
            var verifParcelNumber = parcelNumberAVerifier && parcelNumber.val().length > 4;
            if (verifParcelNumber) { validParcelNumber(); }
        },
        close: function (event, ui) { validParcelNumber(); }
    });

    function removeParcelNumb() {
        parcelNumberValide.removeClass("validGlyphiconOk");
        parcelNumberRemouve.removeClass("validGlyphiconRemouve");
        parcelNumber.val('');
        SearchCic.css("visibility", "hidden");
    };
    function validParcelNumber() {

        parcelNumberAVerifier = false;

        if (customerRef.val() === null) {
            customerRef.val(" ");
        }
        if (productRef.val() === null) {
            productRef.val(" ");
        }

        if (parcelNumber.val()) {
            $.ajax({
                type: "Post",
                url: "coliExist",
                data: { cliCod: cliCod.val().trim(), etbNum: etbNum.val().trim(), customerRef: customerRef.val().trim(), productRef: productRef.val().trim(), parcelNumber: parcelNumber.val().trim() },
                success: function (data) {

                    if (data) {
                        searchCustomerRef();
                        searchProductRef();
                        parcelNumberValide.addClass("validGlyphiconOk");
                        SearchCic.css("visibility", "visible");

                    } else {
                        $('#messageErrorParcelNumber').show();
                        removeParcelNumb()
                        parcelNumberValide.removeClass("validGlyphiconOk");
                    }
                },
                error: function () { alert("error ajax verif n° de colis"); },
            })
        }

    };
    function DisplayElementParcelNumber() { };
    /////////////////////////////////////////////////////////////////////////////////////
    let SearchCic = $("#SearchCic");
  
    SearchCic.click(function () { loader.addClass("DisplayWrapper"); });
    
});

